package aggregation_and_composition.the_gamer_library_aggregation;

public class Game {
    
    private String title;
    private String genre;
    
    public Game(String title, String genre) {
        this.title = title;
        this.genre = genre;
    }

    @Override
    public String toString() {
        return "Game [title=" + title + ", genre=" + genre + "]";
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

}
