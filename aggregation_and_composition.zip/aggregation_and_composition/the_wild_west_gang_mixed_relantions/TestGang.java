package aggregation_and_composition.the_wild_west_gang_mixed_relantions;

public class TestGang {
    
    public static void main(String[] args) {
        
        Camp camp1 = new Camp("Desert", 5);
        Camp camp2 = new Camp("Mountains", 3);

        Gang gang1 = new Gang("The Desert Rats", camp1);
        Gang gang2 = new Gang("The Mountain Wolves", camp2);

        Outlaw outlaw1 = new Outlaw("Billy the Kid", 5000.0);
        Outlaw outlaw2 = new Outlaw("Jesse James", 10000.0);
        Outlaw outlaw3 = new Outlaw("Butch Cassidy", 8000.0);

        gang1.recruitOutlaw(outlaw1);
        gang1.recruitOutlaw(outlaw2);

        gang2.recruitOutlaw(outlaw3);

        System.out.println(gang1);
        System.out.println(gang2);

        gang1.removeOutlaw(outlaw1);

        System.out.println("After removing Billy the Kid from The Desert Rats:");
        System.out.println(gang1);
    }
}
